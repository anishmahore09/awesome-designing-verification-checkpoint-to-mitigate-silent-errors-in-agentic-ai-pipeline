"""Gate G2 (data/baseline validation): can the recorded tau-bench trajectories be replayed
faithfully, and do recomputed rewards match the recorded labels?

Writes results/replay_validation.csv (one row per trajectory) and prints a summary.
Usage: python -I scripts/validate_replay.py --tau_root ../data_raw/tau-bench
"""
import argparse, json, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import pandas as pd
from tau_env import TauDomain, parse_steps, replay, recompute_reward

ap = argparse.ArgumentParser()
ap.add_argument("--tau_root", required=True)
a = ap.parse_args()
FILES = json.load(open("configs/experiment.json"))["trajectory_files"]
rows = []
t0 = time.time()
for fname, (model, domain) in FILES.items():
    dom = TauDomain(a.tau_root, domain)
    trajs = json.load(open(os.path.join(a.tau_root, "historical_trajectories", fname)))
    for k, t in enumerate(trajs):
        steps = parse_steps(t["traj"])
        steps, final = replay(dom, steps)
        calls = [s for s in steps if s["kind"] == "tool_call"]
        mism = [s for s in calls if s["recorded"] is not None and s["observed"] != s["recorded"]]
        r = recompute_reward(dom, final, t["info"]["task"], steps)
        rows.append({"file": fname, "model": model, "domain": domain, "row": k, "task_id": t["task_id"],
                     "trial": t["trial"], "reward": t["reward"], "reward_recomputed": r,
                     "n_calls": len(calls), "n_output_mismatch": len(mism),
                     "first_mismatch_tool": mism[0]["name"] if mism else ""})
df = pd.DataFrame(rows)
df.to_csv("results/replay_validation.csv", index=False)
print(f"trajectories: {len(df)}  tool calls: {df.n_calls.sum()}  time {time.time()-t0:.1f}s")
print("trajectories with >=1 replay/recorded output mismatch:", int((df.n_output_mismatch > 0).sum()))
print("total mismatching calls:", int(df.n_output_mismatch.sum()))
print(df[df.n_output_mismatch > 0].groupby(["file", "first_mismatch_tool"]).size())
print("reward agreement:", int((df.reward == df.reward_recomputed).sum()), "/", len(df))
print(df.groupby(["model", "domain"]).agg(n=("reward", "size"), success=("reward", "mean"),
                                          agree=("reward_recomputed", lambda s: (s == df.loc[s.index, "reward"]).mean())))
