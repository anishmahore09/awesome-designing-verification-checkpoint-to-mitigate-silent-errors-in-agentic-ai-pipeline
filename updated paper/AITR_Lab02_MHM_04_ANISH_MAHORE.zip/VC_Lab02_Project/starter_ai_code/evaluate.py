import argparse
import csv
import json
from collections import defaultdict

def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def as_binary(value, field, row_id):
    if value not in {"0", "1"}:
        raise ValueError(f"{field} must be 0 or 1 for trace_id={row_id}; got {value!r}")
    return int(value)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", required=True)
    parser.add_argument("--labels", required=True)
    parser.add_argument("--output", default="results.json")
    args = parser.parse_args()

    preds = read_csv(args.predictions)
    labels = read_csv(args.labels)
    pred_by_id = {}
    for row in preds:
        tid = row.get("trace_id", "")
        if not tid or tid in pred_by_id:
            raise ValueError(f"Missing or duplicate prediction trace_id: {tid!r}")
        pred_by_id[tid] = row
    label_by_id = {}
    for row in labels:
        tid = row.get("trace_id", "")
        if not tid or tid in label_by_id:
            raise ValueError(f"Missing or duplicate label trace_id: {tid!r}")
        label_by_id[tid] = row
    if set(pred_by_id) != set(label_by_id):
        missing_pred = sorted(set(label_by_id) - set(pred_by_id))
        missing_label = sorted(set(pred_by_id) - set(label_by_id))
        raise ValueError(f"ID mismatch; missing predictions={missing_pred[:5]}, missing labels={missing_label[:5]}")

    y_true, y_pred = [], []
    for tid in sorted(label_by_id):
        y_true.append(as_binary(label_by_id[tid].get("ground_truth_fault", ""), "ground_truth_fault", tid))
        y_pred.append(as_binary(pred_by_id[tid].get("predicted_fault", ""), "predicted_fault", tid))

    tp = sum(a == 1 and b == 1 for a, b in zip(y_true, y_pred))
    tn = sum(a == 0 and b == 0 for a, b in zip(y_true, y_pred))
    fp = sum(a == 0 and b == 1 for a, b in zip(y_true, y_pred))
    fn = sum(a == 1 and b == 0 for a, b in zip(y_true, y_pred))
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    fpr = fp / (fp + tn) if fp + tn else 0.0
    result = {
        "n_traces": len(y_true), "positive_traces": sum(y_true),
        "tp": tp, "tn": tn, "fp": fp, "fn": fn,
        "precision": precision, "recall": recall, "f1": f1,
        "false_positive_rate": fpr
    }
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
