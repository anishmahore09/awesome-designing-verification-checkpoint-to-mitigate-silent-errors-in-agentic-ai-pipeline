import json
import os
import platform
import sys
from pathlib import Path

def main():
    cwd = Path.cwd()
    writable = os.access(cwd, os.W_OK)
    result = {
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        "working_directory": str(cwd),
        "working_directory_writable": writable,
        "status": "PASS" if writable else "FAIL"
    }
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if writable else 1)

if __name__ == "__main__":
    main()
