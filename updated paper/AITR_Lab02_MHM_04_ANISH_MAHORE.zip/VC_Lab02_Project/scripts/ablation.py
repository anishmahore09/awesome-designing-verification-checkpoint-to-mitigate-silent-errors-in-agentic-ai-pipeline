"""Leave-one-checkpoint-out ablation on TEST (Prompt 12): what does each deterministic family add?"""
import pandas as pd
from itertools import chain
T = pd.read_csv("results/traj_test.csv")
T["fail"] = 1 - T.reward
T["silent"] = (T.fail == 1) & (T.n_any_errors == 0) & (T.transferred == 0)
DET = ["C1_permission", "C2_confirmation", "C3_policy", "C4_grounding", "C5_duplicate", "C6_report"]
rows = []
for drop in [None] + DET:
    cols = [c for c in DET if c != drop]
    p = T[cols].max(axis=1)
    rows.append({"removed": drop or "(none)", "recall_fail": p[T.fail == 1].mean(), "recall_silent": p[T.silent].mean(),
                 "fpr": p[T.fail == 0].mean(), "unique_failures_lost": int(((T[DET].max(axis=1) == 1) & (p == 0) & (T.fail == 1)).sum())})
pd.DataFrame(rows).to_csv("results/table_ablation.csv", index=False)
print(pd.DataFrame(rows).round(3).to_string())
