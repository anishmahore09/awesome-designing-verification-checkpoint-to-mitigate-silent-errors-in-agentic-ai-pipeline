# One-page research brief (Gate G1)

| Field | Content |
|---|---|
| Review topic and key papers | Verification checkpoints against silent errors in agentic pipelines (Mahore 2026, MHM_04). Key sources: tau-bench (Yao et al., ICLR 2025); ToolSafe (Findings of ACL 2026); VIGIL (ACL 2026); Dubey 2026 (arXiv 2608.02464); REFLECT (arXiv 2606.09071) |
| Research gap | The review proposes checkpoint positions and a layered deterministic → semantic → human design (§4, §7) and asks for detection rate, FPR, earliest step and latency (§9.5), but measures nothing |
| Research question | On real outcome-labelled tool-agent runs, what share of silent failures do deterministic pre/post-action checkpoints flag, at what false-alarm rate, and which faults do they miss? |
| Study pathway | B (controlled comparison) plus controlled fault injection |
| Dataset / measurement | tau-bench historical trajectories: 1,980 runs (GPT-4o, Claude 3.5 Sonnet; retail, airline); reward from final DB state |
| Baseline / comparators | E exception monitor (what an unguarded pipeline sees); C1–C6 deterministic checkpoints; layered E + C1–C6 |
| Primary metric and control | Recall on failed and silent runs vs. FPR on successful runs; task-level dev/test split; rules frozen before test; cluster bootstrap CIs |
| Computing and risks | CPU, < 1 GB RAM, about 9 min end-to-end. Risks: rule authoring bias, two domains only, outcome labels include output checks |
| First executable milestone | Data validation + state reconstruction (2,026/2,026) + 12 unit tests (logs/03, 09, 10) |
