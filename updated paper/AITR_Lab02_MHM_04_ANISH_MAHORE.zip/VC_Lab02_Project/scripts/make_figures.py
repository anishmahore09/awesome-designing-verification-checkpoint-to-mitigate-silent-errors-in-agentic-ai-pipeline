"""All paper figures, regenerated from results/*.csv."""
import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np, pandas as pd

OUT = "paper/figures"; os.makedirs(OUT, exist_ok=True)
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, MUTED, GRID = "#0b0b0b", "#52514e", "#e4e3df"
plt.rcParams.update({"font.size": 8, "font.family": "DejaVu Sans", "axes.edgecolor": MUTED, "axes.labelcolor": INK,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
                     "legend.frameon": False, "savefig.bbox": "tight", "savefig.dpi": 300})
NICE = {"E": "E exception monitor", "C1_permission": "C1 permission", "C2_confirmation": "C2 confirmation",
        "C3_policy": "C3 policy", "C4_grounding": "C4 grounding", "C5_duplicate": "C5 duplicate",
        "C6_report": "C6 report vs. result", "DET": "C1-C6 combined", "LAYERED": "E + C1-C6"}

# Fig A: recall on silent failures vs FPR (with CIs)
m = pd.read_csv("results/table_main.csv").set_index("checkpoint")
fig, ax = plt.subplots(figsize=(5.0, 2.8))
for k in m.index:
    r = m.loc[k]
    col = ORANGE if k in ("DET", "LAYERED") else (MUTED if k == "E" else BLUE)
    ax.errorbar(r.fpr, r.recall_fail, xerr=[[r.fpr - r.fpr_lo], [r.fpr_hi - r.fpr]],
                yerr=[[r.recall_fail - r.recall_fail_lo], [r.recall_fail_hi - r.recall_fail]],
                fmt="o", ms=4.5, color=col, ecolor=col, elinewidth=1, capsize=0, mec="white", mew=0.8, zorder=3)
off = {"E": (4, 2), "C2_confirmation": (4, -2), "C3_policy": (4, 4), "DET": (5, -3), "LAYERED": (-4, 5),
       "C1_permission": (4, 3), "C6_report": (4, -6), "C4_grounding": (5, 6), "C5_duplicate": (5, -9)}
for k in ["E", "C2_confirmation", "C3_policy", "DET", "LAYERED"]:
    r = m.loc[k]
    ha = "right" if k == "LAYERED" else "left"
    ax.annotate(NICE[k], (r.fpr, r.recall_fail), xytext={"E": (6, 0), "C2_confirmation": (6, -3), "C3_policy": (-6, 8),
                "DET": (6, 3), "LAYERED": (-6, 6)}[k], textcoords="offset points", fontsize=7, color=INK, ha=ha, va="center")
ax.annotate("C1, C4, C5, C6 (each < 0.03)", (0.008, 0.015), xytext=(30, -2), textcoords="offset points", fontsize=7,
            color=INK, va="center", arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.6))
ax.plot([0, 0.6], [0, 0.6], ls=":", color=MUTED, lw=0.8)
ax.text(0.47, 0.43, "chance", fontsize=6, color=MUTED, rotation=37)
ax.set_xlim(-0.01, 0.6); ax.set_ylim(-0.01, 0.65)
ax.set_xlabel("false-alarm rate on successful runs"); ax.set_ylabel("recall of failed runs")
fig.savefig(f"{OUT}/fig_recall_fpr.pdf")

# Fig B: failure types (share) and detection by E vs C1-C6
ft = pd.read_csv("results/table_failure_types.csv")
ft = ft[ft.failure_type != "no write needed or made"].sort_values("n")
fig, ax = plt.subplots(figsize=(3.4, 2.3))
y = np.arange(len(ft)); h = 0.36
ax.barh(y + h / 2, ft.DET, h, color=ORANGE, label="checkpoints C1-C6")
ax.barh(y - h / 2, ft.E, h, color=MUTED, label="exception monitor E")
labels = [f"{t} (n={n})" for t, n in zip(ft.failure_type, ft.n)]
ax.set_yticks(y, labels, fontsize=6.8)
ax.set_xlim(0, 1); ax.set_xlabel("share of failed test runs flagged")
ax.legend(loc="lower right", fontsize=6.5)
fig.savefig(f"{OUT}/fig_failure_types.pdf")

# Fig C: injection heatmap
inj = pd.read_csv("results/table_injection.csv").set_index("variant")
order = ["clean", "I1_confirmation_removed", "I2_cross_user_target", "I3_same_user_wrong_target", "I4_duplicate_write"]
cols = ["E", "C1_permission", "C2_confirmation", "C3_policy", "C4_grounding", "C5_duplicate", "C6_report", "DET"]
M = inj.loc[order, cols].values
fig, ax = plt.subplots(figsize=(3.4, 1.9))
ax.imshow(M, cmap="Blues", vmin=0, vmax=1, aspect="auto")
ax.grid(False)
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        ax.text(j, i, f"{M[i, j]:.2f}", ha="center", va="center", fontsize=6, color="white" if M[i, j] > 0.6 else INK)
ax.set_xticks(range(len(cols)), ["E", "C1", "C2", "C3", "C4", "C5", "C6", "C1-6"])
ax.set_yticks(range(len(order)), [f"{o.split('_',1)[-1].replace('_',' ')} (n={int(inj.loc[o,'n'])})" if o != "clean" else f"untouched (n={int(inj.loc[o,'n'])})" for o in order], fontsize=6.5)
ax.tick_params(length=0)
for s in ax.spines.values(): s.set_visible(False)
fig.savefig(f"{OUT}/fig_injection.pdf")

# Fig D: by model x domain: silent share of failures and C1-C6 recall on silent failures
g = pd.read_csv("results/table_by_group.csv")
d = g[g.checkpoint == "DET"].copy()
d["label"] = d.model.str.replace("claude-3.5-sonnet-new", "Sonnet").str.replace("gpt-4o", "GPT-4o") + "\n" + d.domain
x = np.arange(len(d)); w = 0.36
fig, ax = plt.subplots(figsize=(3.4, 2.3))
ax.bar(x - w / 2, d.silent_share_of_fail, w, color=MUTED, label="silent share of failures")
ax.bar(x + w / 2, d.recall_silent, w, color=ORANGE, label="silent failures flagged by C1-C6")
for i, (a, b) in enumerate(zip(d.silent_share_of_fail, d.recall_silent)):
    ax.text(i - w / 2, a + 0.02, f"{a:.2f}", ha="center", fontsize=6); ax.text(i + w / 2, b + 0.02, f"{b:.2f}", ha="center", fontsize=6)
ax.set_xticks(x, d.label, fontsize=6.5); ax.set_ylim(0, 0.85); ax.set_ylabel("share")
ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), fontsize=6.5, ncol=2)
fig.savefig(f"{OUT}/fig_groups.pdf")
print("figures written")
