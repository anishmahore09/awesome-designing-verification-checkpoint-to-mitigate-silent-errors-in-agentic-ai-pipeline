#!/usr/bin/env bash
# Clone the public tau-bench repository at the pinned commit. Only its JSON data files are read;
# none of its Python code is imported or executed by this project.
set -euo pipefail
DEST=${1:-../data_raw/tau-bench}
COMMIT=59a200c6d575d595120f1cb70fea53cef0632f6b
[ -d "$DEST" ] || git clone -q https://github.com/sierra-research/tau-bench "$DEST"
git -C "$DEST" checkout -q "$COMMIT"
echo "ok tau-bench at $(git -C "$DEST" rev-parse HEAD)"
