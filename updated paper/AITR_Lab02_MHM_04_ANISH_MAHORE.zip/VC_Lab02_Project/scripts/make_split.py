"""Task-level dev/test split (frozen before any detector is run on test data).
All trials of a task, for both models, go to the same split. Seed 2026, 40% of tasks per domain -> dev."""
import json
import numpy as np, pandas as pd

cfg = json.load(open("configs/experiment.json"))
idx = pd.read_csv("results/trajectory_index.csv")
rng = np.random.default_rng(cfg["split"]["seed"])
assign = {}
for dom in sorted(idx.domain.unique()):
    tasks = np.array(sorted(idx[idx.domain == dom].task_id.unique()))
    perm = rng.permutation(tasks)
    n_dev = int(round(cfg["split"]["dev_fraction"] * len(tasks)))
    for i, t in enumerate(perm):
        assign[(dom, int(t))] = "dev" if i < n_dev else "test"
idx["split"] = [assign[(d, int(t))] for d, t in zip(idx.domain, idx.task_id)]
idx.to_csv("results/trajectory_index.csv", index=False)
print(idx.groupby(["split", "domain"]).agg(tasks=("task_id", "nunique"), trajs=("reward", "size"),
                                         success=("reward", "mean")).round(3).to_string())
