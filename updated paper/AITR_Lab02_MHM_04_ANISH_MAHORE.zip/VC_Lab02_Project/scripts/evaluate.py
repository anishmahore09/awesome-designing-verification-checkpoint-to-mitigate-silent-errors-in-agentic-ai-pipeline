"""Held-out evaluation (TEST split) of the frozen checkpoints + analyses.
Ground-truth task actions are used here ONLY to categorise failures after detection.

Outputs in results/: table_main.csv, table_by_group.csv, table_failure_types.csv,
table_injection.csv, table_cost.csv, numbers.json
Usage: python -I scripts/evaluate.py --tau_root ../data_raw/tau-bench
"""
import argparse, json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import numpy as np, pandas as pd
from tau_env import parse_steps, WRITE_TOOLS, is_error
from checkpoints import CHECKS

ap = argparse.ArgumentParser()
ap.add_argument("--tau_root", required=True)
a = ap.parse_args()
cfg = json.load(open("configs/experiment.json"))
B, SEED = 10000, 2026    # cluster-bootstrap resamples over tasks (as frozen in configs/experiment.json)
T = pd.read_csv("results/traj_test.csv")
F = pd.read_csv("results/flags_test.csv")
T["fail"] = 1 - T.reward
T["silent"] = ((T.fail == 1) & (T.n_any_errors == 0) & (T.transferred == 0)).astype(int)
DET = CHECKS[1:]
T["DET"] = T[DET].max(axis=1)
T["LAYERED"] = T[CHECKS].max(axis=1)
T["task"] = T.domain + ":" + T.task_id.astype(str)
num = {"n_test": len(T), "n_test_fail": int(T.fail.sum()), "n_test_silent": int(T.silent.sum()),
       "n_test_success": int((T.fail == 0).sum()), "n_test_tasks": int(T.task.nunique())}

# ---- cluster bootstrap over tasks
tasks = T.task.unique()
rng = np.random.default_rng(SEED)
groups = {k: g.index.values for k, g in T.groupby("task")}
boot_idx = [np.concatenate([groups[t] for t in rng.choice(tasks, len(tasks), replace=True)]) for _ in range(B)]


def stat(df, col):
    f, s, sl = df[df.fail == 1], df[df.fail == 0], df[df.silent == 1]
    tp, fp = f[col].sum(), s[col].sum()
    return {"recall_fail": f[col].mean(), "recall_silent": sl[col].mean(), "fpr": s[col].mean(),
            "precision": tp / (tp + fp) if tp + fp else np.nan}


def with_ci(col):
    point = stat(T, col)
    bs = {k: [] for k in point}
    for ix in boot_idx:
        st = stat(T.loc[ix], col)
        for k in st:
            bs[k].append(st[k])
    out = {"checkpoint": col}
    for k, v in point.items():
        lo, hi = np.nanpercentile(bs[k], [2.5, 97.5])
        out[k], out[k + "_lo"], out[k + "_hi"] = v, lo, hi
    return out


main = pd.DataFrame([with_ci(c) for c in CHECKS + ["DET", "LAYERED"]])
main.to_csv("results/table_main.csv", index=False)

# ---- by model x domain
g = []
for (m, d), x in T.groupby(["model", "domain"]):
    for c in ["E", "DET", "LAYERED"]:
        s = stat(x, c)
        g.append({"model": m, "domain": d, "checkpoint": c, "n": len(x), "fail_rate": x.fail.mean(),
                  "silent_share_of_fail": x[x.fail == 1].silent.mean(), **s})
pd.DataFrame(g).to_csv("results/table_by_group.csv", index=False)

# ---- failure types (analysis only, uses ground-truth actions)
FILES = cfg["trajectory_files"]
cache, types = {}, []
for _, r in T[T.fail == 1].iterrows():
    if r.file not in cache:
        cache[r.file] = json.load(open(os.path.join(a.tau_root, "historical_trajectories", r.file)))
    t = cache[r.file][int(r.row)]
    dom = r.domain
    steps = parse_steps(t["traj"])
    agent = sorted((s["name"], json.dumps(s["kwargs"], sort_keys=True)) for s in steps
                   if s["kind"] == "tool_call" and s["name"] in WRITE_TOOLS[dom] and not is_error(s["recorded"]))
    gt = sorted((x["name"], json.dumps(x["kwargs"], sort_keys=True)) for x in t["info"]["task"]["actions"] if x["name"] in WRITE_TOOLS[dom])
    if not gt and agent:
        ty = "unrequested write"
    elif gt and not agent:
        ty = "omission (no successful write)"
    elif agent == gt:
        ty = "writes match ground truth"
    elif sorted(n for n, _ in agent) != sorted(n for n, _ in gt):
        ty = "wrong or extra write tool"
    else:
        ty = "right tools, wrong arguments"
    if not gt and not agent:
        ty = "no write needed or made"
    types.append({"traj_key": r.traj_key, "failure_type": ty})
FT = T.merge(pd.DataFrame(types), on="traj_key")
ft = FT.groupby("failure_type").agg(n=("fail", "size"), silent=("silent", "mean"), E=("E", "mean"),
                                     DET=("DET", "mean"), LAYERED=("LAYERED", "mean")).reset_index()
ft["share"] = ft.n / ft.n.sum()
ft.sort_values("n", ascending=False).to_csv("results/table_failure_types.csv", index=False)
FT[["traj_key", "failure_type"]].to_csv("results/failure_types_test.csv", index=False)

# ---- prevention: first deterministic flag fires before the first write executes
fd = F[F.check.isin(DET)].merge(T[["traj_key", "fail"]], on="traj_key")
first = fd.sort_values("step").groupby("traj_key").first()
det_fail = T[(T.fail == 1) & (T.DET == 1)].traj_key
num["DET_flagged_failures"] = int(len(det_fail))
num["DET_flagged_failures_preaction_at_first_flag"] = float(first.loc[first.index.isin(det_fail), "pre_action"].mean())
num["DET_flags_preaction_share"] = float(fd.pre_action.mean())
# where DET flags fire, reasons
num["test_flag_counts"] = F.groupby("check").size().to_dict()
num["test_reason_counts"] = F[F.check.isin(DET)].groupby("reason").size().sort_values(ascending=False).head(12).to_dict()
# process violations on successful runs
num["success_with_DET_flag"] = float(T[T.fail == 0].DET.mean())

# ---- injection
inj = pd.read_csv("results/injection_results.csv")
inj["DET"] = inj[DET].max(axis=1)
inj["LAYERED"] = inj[CHECKS].max(axis=1)
ti = inj.groupby("variant")[CHECKS + ["DET", "LAYERED"]].mean()
ti.insert(0, "n", inj.groupby("variant").size())
ti.to_csv("results/table_injection.csv")
cl = inj[inj.variant == "clean"].set_index("traj_key").DET
for v in ["I1_confirmation_removed", "I2_cross_user_target", "I3_same_user_wrong_target", "I4_duplicate_write"]:
    x = inj[inj.variant == v].set_index("traj_key").DET
    num[f"inj_{v}_new_detections"] = float(((x == 1) & (cl.loc[x.index] == 0)).mean())

# ---- cost
cost = pd.DataFrame({"checks_dense_mean": [T.checks_dense.mean()], "checks_gated_mean": [T.checks_gated.mean()],
                     "ms_median": [T.ms.median()], "ms_p95": [T.ms.quantile(.95)], "steps_mean": [T.n_steps.mean()]})
cost.to_csv("results/table_cost.csv", index=False)
num["gated_over_dense"] = float(T.checks_gated.sum() / T.checks_dense.sum())
json.dump(num, open("results/numbers.json", "w"), indent=1, default=float)
pd.set_option("display.width", 220)
for f in ["table_main", "table_by_group", "table_failure_types", "table_injection", "table_cost"]:
    print(f"\n=== {f}\n", pd.read_csv(f"results/{f}.csv").round(3).to_string())
print(json.dumps(num, indent=1, default=float))
