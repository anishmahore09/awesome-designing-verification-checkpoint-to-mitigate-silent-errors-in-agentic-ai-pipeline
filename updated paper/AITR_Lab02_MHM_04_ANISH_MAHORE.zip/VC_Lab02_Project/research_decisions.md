# research_decisions.md

Tags: **VERIFIED** (checked in a source or by execution; evidence path given), **INFERRED** (reasoning), **UNKNOWN** (missing evidence).
D001–D009 come from the Prompt 01/02 gap matrix (22 Oct 2026). **That gap matrix analysed an earlier 15-page version of the review** (Entropy Principle, PIG/ADE, 18 "Complete References"). The review supplied now (MHM_04, 14 pages) is a revised version with a different structure and a corrected 16-item reference list. Decisions D010 onward refer to the revised review.

| ID | Date | Decision | Reason | Evidence | Status |
|---|---|---|---|---|---|
| D001–D009 | 2026-10-22 | See the gap-matrix PDF (scope, reference mismatches, G1–G5, ranking G5 > G3 > G1) | – | gap matrix | Superseded where noted |
| D010 | 2026-11-14 | Use the revised review (MHM_04) as the scope baseline; map the experiment onto its §3–§9, Eq. 2–9 and Table 1 | It is the version being submitted | review PDF | VERIFIED |
| D011 | 2026-11-14 | Keep the Prompt 03–07 design (pathway B: no checkpoint vs. deterministic checkpoints; fault catalogue; validation-only tuning) but run it on **real public traces** instead of synthetic ones | Real outcome-labelled traces exist (tau-bench historical_trajectories, MIT); Prompt 14 ranked "validate on real traces" as follow-up #3 | sierra-research/tau-bench @ 59a200c6 | VERIFIED |
| D012 | 2026-11-14 | Keep controlled fault injection (I1–I4) on real successful runs as RQ3 | Ground truth by construction, as in the blueprint | scripts/inject_faults.py | VERIFIED |
| D013 | 2026-11-14 | Data-only design: no tau-bench Python code is executed | The AI environment refused execution of the downloaded repository's code; replay was replaced by state reconstruction from JSON data and recorded outputs | ai_assistance_log #3; logs/10 (2026/2026 agreement) | VERIFIED |
| D014 | 2026-11-14 | Labels = tau-bench reward; silent failure = reward 0 ∧ no tool error ∧ no transfer | Matches review §3.1 definition operationally | logs/03 | VERIFIED |
| D015 | 2026-11-14 | Task-level 40/60 dev/test split, seed 2026, both models together | Prevent task leakage | results/trajectory_index.csv | VERIFIED |
| D016 | 2026-11-14 | Checkpoints E, C1–C6 as in configs/experiment.json; no learned or LLM component | No verified model/API access; review's deterministic layer is the testable part | src/checkpoints.py | VERIFIED |
| D017 | 2026-11-14 | Dev-phase rule changes: (a) airline identity may come from a user-stated user ID; (b) basic-economy flight-change rule applies only when the new cabin is also basic economy; (c) confirmation lexicon extended with imperative forms | False positives on dev runs that complied with the written policy | logs/04_dev_phase_rule_changes.diff | VERIFIED; made before the freeze |
| D018 | 2026-11-14 | Freeze code and config, then run test once | Prevent test-set tuning | logs/05_freeze_hashes.log | VERIFIED |
| D019 | 2026-11-14 | Pre-stated expectation H1: ≥ 50% silent recall at FPR ≤ 20% | Stated before the test run | configs/experiment.json | Result: not supported |
| D020 | 2026-11-14 | Starter detector not used as a baseline | Flags 100% of real traces (event grammar mismatch) | logs/11 | VERIFIED |
| D021 | 2026-11-14 | E (exception monitor) is the "no checkpoint" reference; the trivial B0 (never flags) is reported implicitly (recall 0) | E is what an unguarded pipeline actually observes | – | INFERRED |
| D022 | 2026-11-14 | Cluster bootstrap over tasks, 10,000 resamples | Trials of a task are correlated | scripts/evaluate.py | VERIFIED (a 2,000-resample trial run was replaced by the frozen 10,000) |
| D023 | 2026-11-14 | Failure types derived from ground-truth actions only for post-hoc analysis | Keep labels away from detection | scripts/evaluate.py | VERIFIED |
| D024 | 2026-11-14 | Leave-one-checkpoint-out ablation (Prompt 12) | Measure each family's contribution | logs/13 | VERIFIED |
| D025 | 2026-11-14 | Bibliography: review's 16 references reused; 4 of the 2026 papers verified online, and REFLECT's second author corrected to "Yunxi Wang" per arXiv | – | paper/bib_verification.md | Partly VERIFIED |
| D026 | 2026-11-14 | Fresh-copy reproduction | Gate G4 | logs/14 | VERIFIED |

## Open next actions (author)
1. Read src/checkpoints.py against the two policy texts (tau-bench `wiki.md` files) and confirm or revise each rule (the paper's [TO VERIFY] item).
2. Re-run `scripts/run_all.sh` and confirm the checklist in the README.
3. Fill in the institute name and licence. Verify the [TO VERIFY] bibliography entries.
4. Follow-up experiments (ranked): (1) a semantic intent-matching check on write arguments; (2) a goal-based final checkpoint for omissions; (3) block-and-retry recovery to measure correction success.
