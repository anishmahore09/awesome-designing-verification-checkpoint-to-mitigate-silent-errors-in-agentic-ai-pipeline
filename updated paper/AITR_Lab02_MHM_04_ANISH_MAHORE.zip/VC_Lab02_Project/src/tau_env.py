"""Data-only access to the public tau-bench trajectories and databases (MIT, Sierra).

No code from the tau-bench repository is imported or executed. We read
  * historical_trajectories/*.json  (recorded agent runs with their tau-bench reward), and
  * tau_bench/envs/<domain>/data/*.json  (the initial databases),
and reconstruct the database state seen before every state-changing (write) tool call by
applying the objects that the recorded write calls returned (tau-bench write tools return
the updated order / reservation / user as JSON).
"""
import copy, json, os

WRITE_TOOLS = {
    "retail": {"cancel_pending_order", "exchange_delivered_order_items", "modify_pending_order_address",
               "modify_pending_order_items", "modify_pending_order_payment", "modify_user_address",
               "return_delivered_order_items"},
    "airline": {"book_reservation", "cancel_reservation", "send_certificate", "update_reservation_baggages",
                "update_reservation_flights", "update_reservation_passengers"},
}
DB_FILES = {"retail": ["orders", "products", "users"], "airline": ["flights", "reservations", "users"]}


def load_db(tau_root, domain):
    base = os.path.join(tau_root, "tau_bench", "envs", domain, "data")
    return {k: json.load(open(os.path.join(base, f"{k}.json"))) for k in DB_FILES[domain]}


def parse_steps(traj):
    """Flatten a recorded trajectory into ordered steps.
    kinds: 'user', 'assistant_text', 'tool_call' (with name, kwargs, recorded output)."""
    steps, pending = [], {}
    for i, m in enumerate(traj):
        role = m["role"]
        if role == "user":
            steps.append({"kind": "user", "idx": i, "text": m.get("content") or ""})
        elif role == "assistant":
            if m.get("content"):
                steps.append({"kind": "assistant_text", "idx": i, "text": m["content"]})
            for tc in m.get("tool_calls") or []:
                fn = tc["function"]
                try:
                    kw = json.loads(fn["arguments"]) if isinstance(fn["arguments"], str) else fn["arguments"]
                except json.JSONDecodeError:
                    kw = None
                st = {"kind": "tool_call", "idx": i, "name": fn["name"], "kwargs": kw, "recorded": None}
                pending[tc.get("id")] = st
                steps.append(st)
        elif role == "tool":
            st = pending.get(m.get("tool_call_id"))
            if st is not None:
                st["recorded"] = m.get("content") or ""
    return steps


def is_error(output):
    return isinstance(output, str) and (output.startswith("Error") or output.startswith("Unknown action"))


def attach_states(steps, db, domain):
    """Give every write call a 'pre_state' view: the initial DB updated with the objects
    returned by earlier successful write calls in the same trajectory."""
    state = copy.deepcopy(db)
    for st in steps:
        if st["kind"] != "tool_call" or st["name"] not in WRITE_TOOLS[domain]:
            continue
        st["pre_state"] = state
        out = st["recorded"]
        if is_error(out) or out is None:
            continue
        try:
            obj = json.loads(out)
        except (json.JSONDecodeError, TypeError):
            continue
        if not isinstance(obj, dict):
            continue
        state = copy.copy(state)                      # shallow copy of top level; replace touched table
        if domain == "retail" and "order_id" in obj:
            state["orders"] = {**state["orders"], obj["order_id"]: obj}
        elif domain == "retail" and "payment_methods" in obj and st["kwargs"]:
            uid = st["kwargs"].get("user_id")
            if uid:
                state["users"] = {**state["users"], uid: obj}
        elif domain == "airline" and "reservation_id" in obj:
            state["reservations"] = {**state["reservations"], obj["reservation_id"]: obj}
    return steps
