# Bibliography verification (14 Nov 2026)

| Key | How verified | Status |
|---|---|---|
| dubey2026realtime | Web search: arXiv 2608.02464 abstract (2,823 episodes; 0.71 detection at 5% false alarms) | VERIFIED |
| lin2026reflect | Web search: arXiv 2606.09071 author list | VERIFIED; second author is **Yunxi Wang** (the review lists "Yingxu Wang"; corrected) |
| mou2026toolsafe | Web search: arXiv 2601.10156 and ACL Anthology 2026.findings-acl.1850 | VERIFIED (page range from the review not re-checked) |
| lin2026vigil | Web search: ACL Anthology 2026.acl-long.443, pp. 9764–9785 | VERIFIED |
| yao2025taubench, taubenchrepo | Repository used directly at a pinned commit; paper metadata as listed in the review | Repository VERIFIED; paper metadata [TO VERIFY] |
| yao2023react, schick2023toolformer, liu2024agentbench, lu2025toolsandbox, shinn2023reflexion, yang2024sweagent, debenedetti2024agentdojo, qin2023toolllm | Metadata as listed in the review | [TO VERIFY] (well-known papers) |
| wang2026sidecar, liu2026reflectool, dantas2026safe | Metadata as listed in the review; not opened in this session | [TO VERIFY] |
| efron1993bootstrap | Standard reference | [TO VERIFY] |
| mahore2026review | The author's own review | – |
