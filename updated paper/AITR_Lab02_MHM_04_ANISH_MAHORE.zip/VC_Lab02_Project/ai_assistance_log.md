# AI assistance and provenance log

An AI assistant (Claude) produced the gap matrix (Prompts 01–02) and the planning and starter bundle (Prompts 03–14). In a supervised session on 14 Nov 2026 it implemented, ran and wrote up this study. **The author must review, re-run and be able to explain every module before submission.**

| # | Task | AI proposal | Verification step | Change | Outcome |
|---|---|---|---|---|---|
| 1 | Scope | Gap matrix based on an older 15-page review version | Compared it with the supplied revised review (MHM_04) | The experiment is mapped onto the revised review (D010) | – |
| 2 | Data | Prompts 03–07: synthetic traces | Searched for public outcome-labelled agent traces; found tau-bench historical trajectories (MIT) | Real traces plus injection (D011, D012) | Pinned commit |
| 3 | Replay | Run tau-bench tools to replay trajectories | **The AI environment refused execution of the downloaded repository's code** | Data-only state reconstruction; validated against 2,026 recorded reads | Real limitation #1 |
| 4 | Environment test | Starter `environment_test.py` | Ran it: PASS | – | logs/01 |
| 5 | Starter detector | Starter `checkpoints.py` | **Ran it on real traces: flags 100%** | Not used (D020) | Real limitation #2 |
| 6 | Rules | AI wrote C1–C6 from the policy texts | Debugged on dev only (3 logged changes), then frozen | logs/04 diff | **Author must review the rules** |
| 7 | Evaluation | Starter `evaluate.py` | Used as an independent cross-check: exact agreement | – | logs/12 |
| 8 | Statistics | Cluster bootstrap | A first run used 2,000 resamples; re-run with the frozen 10,000 | Numbers unchanged to 2 decimals | logs/08 |
| 9 | Injection | AI designed I1–I4 from the blueprint's fault catalogue | Run after the freeze | – | logs/07 |
| 10 | References | AI reused the review's list | Web-checked Dubey, REFLECT, ToolSafe and VIGIL; corrected REFLECT's second author | – | bib_verification.md |
| 11 | Manuscript | AI drafted it from the result files | All numbers come from generated macros; [TO VERIFY] markers left | – | **Author to revise in own words** |

## Conclusions that depend on human judgment
* Whether each rule matches the policy as a human agent would read it.
* Whether runs flagged as "successful but violating" are true violations (e.g., confirmation phrasing).
* The failure-type categories, which are an approximation.

## Remaining risks
* Only two domains and two models were studied.
* The rules, queries and text were drafted by an AI.
* No human labelling of individual flags was done.
