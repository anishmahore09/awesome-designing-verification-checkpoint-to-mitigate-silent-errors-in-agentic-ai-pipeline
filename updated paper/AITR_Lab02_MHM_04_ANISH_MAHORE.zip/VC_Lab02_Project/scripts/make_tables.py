"""LaTeX tables and number macros generated from results/ (every result number in the paper)."""
import json, os, re
import pandas as pd

OUT = "paper/generated"; os.makedirs(OUT, exist_ok=True)
num = json.load(open("results/numbers.json"))
idx = pd.read_csv("results/trajectory_index.csv")
NICE = {"E": "E\\ exception monitor", "C1_permission": "C1 permission / identity", "C2_confirmation": "C2 explicit confirmation",
        "C3_policy": "C3 policy precondition", "C4_grounding": "C4 argument grounding", "C5_duplicate": "C5 duplicate write",
        "C6_report": "C6 report vs.\\ result", "DET": "C1--C6 combined", "LAYERED": "E + C1--C6 (layered)"}
mac = {}


def sg(s):
    s = re.sub(r"(?<![\d\-])-(\d)", r"$-$\1", str(s))
    return s


def f3(x): return f"{x:.3f}"
def pc(x): return f"{100*x:.1f}\\%"
def ci(r, k): return f"{r[k]:.3f} [{r[k+'_lo']:.2f}, {r[k+'_hi']:.2f}]"


# dataset
f = idx[idx.reward == 0]
sil = f[(f.n_any_errors == 0) & (f.transferred == 0)]
mac.update(NTraj=f"{len(idx):,}", NCalls=f"{idx.n_calls.sum():,}", NWrites=f"{idx.n_writes.sum():,}", NFail=len(f),
           NSilent=len(sil), SilentShare=pc(len(sil) / len(f)), NTasksAir=idx[idx.domain == "airline"].task_id.nunique(),
           NTasksRet=idx[idx.domain == "retail"].task_id.nunique(), NNoRewardInfo=14,
           NTest=num["n_test"], NTestFail=num["n_test_fail"], NTestSilent=num["n_test_silent"], NTestSucc=num["n_test_success"],
           NTestTasks=num["n_test_tasks"], TestSilentShare=pc(num["n_test_silent"] / num["n_test_fail"]),
           NDev=int((idx.split == "dev").sum()))
ds = idx.groupby(["model", "domain"]).agg(n=("reward", "size"), tasks=("task_id", "nunique"), succ=("reward", "mean"),
                                         writes=("n_writes", "mean"), err=("n_any_errors", lambda s: (s > 0).mean()),
                                         tr=("transferred", "mean")).reset_index()
silent_share = []
for _, r in ds.iterrows():
    x = idx[(idx.model == r.model) & (idx.domain == r.domain) & (idx.reward == 0)]
    silent_share.append(((x.n_any_errors == 0) & (x.transferred == 0)).mean())
ds["silent"] = silent_share
rows = [f"{r.model.replace("claude-3.5-sonnet-new","Claude 3.5 Sonnet").replace("gpt-4o","GPT-4o")} & {r.domain} & {r.tasks} & {r.n} & {f3(r.succ)} & {r.writes:.2f} & {f3(r.err)} & {f3(r.tr)} & {f3(r.silent)} \\\\" for _, r in ds.iterrows()]
open(f"{OUT}/tab_data.tex", "w").write("\n".join(rows))

# main
m = pd.read_csv("results/table_main.csv").set_index("checkpoint")
rows = []
for k in ["E", "C1_permission", "C2_confirmation", "C3_policy", "C4_grounding", "C5_duplicate", "C6_report", "DET", "LAYERED"]:
    r = m.loc[k]
    rule = "\\midrule\n" if k == "DET" else ""
    rows.append(f"{rule}{NICE[k]} & {ci(r,'recall_fail')} & {ci(r,'recall_silent')} & {ci(r,'fpr')} & {f3(r.precision)} \\\\")
open(f"{OUT}/tab_main.tex", "w").write(sg("\n".join(rows)))
D, E, L = m.loc["DET"], m.loc["E"], m.loc["LAYERED"]
mac.update(DETrec=f3(D.recall_fail), DETrecCI=f"[{D.recall_fail_lo:.2f}, {D.recall_fail_hi:.2f}]", DETsil=f3(D.recall_silent),
           DETsilCI=f"[{D.recall_silent_lo:.2f}, {D.recall_silent_hi:.2f}]", DETfpr=f3(D.fpr), DETfprCI=f"[{D.fpr_lo:.2f}, {D.fpr_hi:.2f}]",
           DETprec=f3(D.precision), Erec=f3(E.recall_fail), Efpr=f3(E.fpr), Eprec=f3(E.precision), Lrec=f3(L.recall_fail),
           LrecCI=f"[{L.recall_fail_lo:.2f}, {L.recall_fail_hi:.2f}]", Lfpr=f3(L.fpr), Lsil=f3(L.recall_silent),
           CTwoRec=f3(m.loc["C2_confirmation", "recall_fail"]), CTwoFpr=f3(m.loc["C2_confirmation", "fpr"]),
           CThreeRec=f3(m.loc["C3_policy", "recall_fail"]), CThreeSil=f3(m.loc["C3_policy", "recall_silent"]),
           CThreeFpr=f3(m.loc["C3_policy", "fpr"]), CThreePrec=f3(m.loc["C3_policy", "precision"]))

# groups
g = pd.read_csv("results/table_by_group.csv")
d = g[g.checkpoint == "DET"].set_index(["model", "domain"])
mac.update(AirSilSonnet=f3(d.loc[("claude-3.5-sonnet-new", "airline"), "recall_silent"]),
           AirSilGpt=f3(d.loc[("gpt-4o", "airline"), "recall_silent"]),
           RetSilSonnet=f3(d.loc[("claude-3.5-sonnet-new", "retail"), "recall_silent"]),
           RetSilGpt=f3(d.loc[("gpt-4o", "retail"), "recall_silent"]),
           AirFprSonnet=f3(d.loc[("claude-3.5-sonnet-new", "airline"), "fpr"]), AirFprGpt=f3(d.loc[("gpt-4o", "airline"), "fpr"]))

# failure types
ft = pd.read_csv("results/table_failure_types.csv")
rows = [f"{r.failure_type} & {r.n} & {pc(r.share)} & {f3(r.silent)} & {f3(r.E)} & {f3(r.DET)} & {f3(r.LAYERED)} \\\\" for _, r in ft.iterrows()]
open(f"{OUT}/tab_failure_types.tex", "w").write("\n".join(rows))
ftx = ft.set_index("failure_type")
mac.update(OmitN=int(ftx.loc["omission (no successful write)", "n"]), OmitShare=pc(ftx.loc["omission (no successful write)", "share"]),
           OmitDET=f3(ftx.loc["omission (no successful write)", "DET"]), UnreqDET=f3(ftx.loc["unrequested write", "DET"]),
           WrongArgDET=f3(ftx.loc["right tools, wrong arguments", "DET"]), WrongArgN=int(ftx.loc["right tools, wrong arguments", "n"]),
           WrongToolDET=f3(ftx.loc["wrong or extra write tool", "DET"]))

# injection
inj = pd.read_csv("results/table_injection.csv").set_index("variant")
mac.update(InjN=int(inj.loc["clean", "n"]), InjThreeN=int(inj.loc["I3_same_user_wrong_target", "n"]),
           InjThreeDET=f3(inj.loc["I3_same_user_wrong_target", "DET"]), InjCleanDET=f3(inj.loc["clean", "DET"]),
           InjThreeNew=f3(num["inj_I3_same_user_wrong_target_new_detections"]), InjTwoN=int(inj.loc["I2_cross_user_target", "n"]),
           InjOneNew=f3(num["inj_I1_confirmation_removed_new_detections"]))

# ablation, cost, prevention
ab = pd.read_csv("results/table_ablation.csv").set_index("removed")
mac.update(AbNoCTwoSil=f3(ab.loc["C2_confirmation", "recall_silent"]), AbNoCThreeSil=f3(ab.loc["C3_policy", "recall_silent"]),
           AbNoCTwoFpr=f3(ab.loc["C2_confirmation", "fpr"]), AbCTwoLost=int(ab.loc["C2_confirmation", "unique_failures_lost"]),
           AbCThreeLost=int(ab.loc["C3_policy", "unique_failures_lost"]))
c = pd.read_csv("results/table_cost.csv").iloc[0]
mac.update(ChecksDense=f"{c.checks_dense_mean:.0f}", ChecksGated=f"{c.checks_gated_mean:.0f}", GatedPct=pc(num["gated_over_dense"]),
           MsMedian=f"{c.ms_median:.0f}", MsPninetyfive=f"{c.ms_p95:.0f}", StepsMean=f"{c.steps_mean:.0f}")
mac.update(PreActionShare=pc(num["DET_flagged_failures_preaction_at_first_flag"]), DETflagged=num["DET_flagged_failures"],
           SuccWithFlag=pc(num["success_with_DET_flag"]), NoConfirmFlags=num["test_reason_counts"]["no_explicit_confirmation"],
           CancelInelig=num["test_reason_counts"]["cancel_not_eligible"], SegFlown=num["test_reason_counts"]["segment_already_flown"])
with open(f"{OUT}/numbers.tex", "w") as fh:
    fh.write("% AUTO-GENERATED by scripts/make_tables.py -- do not edit\n")
    for k, v in mac.items():
        fh.write(f"\\newcommand{{\\{k}}}{{{sg(v)}}}\n")
print(len(mac), "macros")
