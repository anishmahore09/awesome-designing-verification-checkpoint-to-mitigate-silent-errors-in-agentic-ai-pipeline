"""Validate the reconstructed pre-action state (no tau-bench code executed).

For every write call whose target (order / reservation) was read earlier in the same
trajectory by get_order_details / get_reservation_details, with no write on that object in
between, the read output must equal the reconstructed pre-state object.
Usage: python -I scripts/validate_state.py --tau_root ../data_raw/tau-bench
"""
import argparse, json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import pandas as pd
from tau_env import load_db, parse_steps, attach_states, WRITE_TOOLS, is_error

ap = argparse.ArgumentParser()
ap.add_argument("--tau_root", required=True)
a = ap.parse_args()
cfg = json.load(open("configs/experiment.json"))
dbs = {d: load_db(a.tau_root, d) for d in ("retail", "airline")}
READ = {"retail": ("get_order_details", "order_id", "orders"), "airline": ("get_reservation_details", "reservation_id", "reservations")}
n = agree = 0
bad = []
for fname, (model, domain) in cfg["trajectory_files"].items():
    rname, key, table = READ[domain]
    for k, t in enumerate(json.load(open(os.path.join(a.tau_root, "historical_trajectories", fname)))):
        steps = attach_states(parse_steps(t["traj"]), dbs[domain], domain)
        last_read = {}
        for s in steps:
            if s["kind"] != "tool_call" or s["kwargs"] is None:
                continue
            obj_id = s["kwargs"].get(key)
            if s["name"] == rname and not is_error(s["recorded"]):
                last_read[obj_id] = s["recorded"]
            elif s["name"] in WRITE_TOOLS[domain] and obj_id in last_read:
                pre = s["pre_state"][table].get(obj_id)
                n += 1
                ok = pre is not None and json.loads(last_read[obj_id]) == pre
                agree += ok
                if not ok and len(bad) < 5:
                    bad.append((fname, k, s["name"], obj_id))
                last_read.pop(obj_id, None)          # object changes after this write
print(f"write calls with an earlier read of the same object: {n}; reconstructed pre-state identical: {agree} ({agree/n:.4f})")
print("first disagreements:", bad)
