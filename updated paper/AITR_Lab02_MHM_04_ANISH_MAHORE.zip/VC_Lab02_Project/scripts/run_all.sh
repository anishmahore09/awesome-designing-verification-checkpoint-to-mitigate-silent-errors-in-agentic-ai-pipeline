#!/usr/bin/env bash
# Full pipeline. Usage: bash scripts/run_all.sh [TAU_ROOT]   (default ../data_raw/tau-bench)
set -euo pipefail
TAU=${1:-../data_raw/tau-bench}
mkdir -p results/logs
python3 -I starter_ai_code/environment_test.py > results/logs/01_starter_environment_test.log || true
python3 -I scripts/validate_data.py --tau_root "$TAU" | tee results/logs/03_data_validation.log
python3 -I scripts/make_split.py
python3 -I tests/test_checkpoints.py | tee results/logs/09_unit_tests.log
python3 -I scripts/validate_state.py --tau_root "$TAU" | tee results/logs/10_state_reconstruction.log
python3 -I scripts/run_checkpoints.py --tau_root "$TAU" --split dev
python3 -I scripts/run_checkpoints.py --tau_root "$TAU" --split test | tee results/logs/06_run_test.log
python3 -I scripts/inject_faults.py --tau_root "$TAU" | tee results/logs/07_injection.log
python3 -I scripts/evaluate.py --tau_root "$TAU" > results/logs/08_evaluate_test.log
python3 -I scripts/ablation.py | tee results/logs/13_ablation.log
python3 -I scripts/make_figures.py
python3 -I scripts/make_tables.py
echo "Compile paper/main.tex on Overleaf (or: cd paper && pdflatex main && bibtex main && pdflatex main && pdflatex main)"
