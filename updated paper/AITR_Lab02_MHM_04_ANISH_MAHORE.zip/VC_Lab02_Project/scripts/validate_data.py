"""Gate G2 (data validation) for the tau-bench trajectories, data-only (no tau-bench code run).

Checks: every trajectory parses; every tool call has a recorded observation; the reward is
binary and equals info.reward_info.reward; per-file success rates; duplicate (task, trial)
pairs; which write tools appear; how often a write call's recorded output is an error.
Writes results/trajectory_index.csv (one row per trajectory) used by later scripts.
Usage: python -I scripts/validate_data.py --tau_root ../data_raw/tau-bench
"""
import argparse, json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import pandas as pd
from tau_env import WRITE_TOOLS, parse_steps, is_error

ap = argparse.ArgumentParser()
ap.add_argument("--tau_root", required=True)
a = ap.parse_args()
FILES = json.load(open("configs/experiment.json"))["trajectory_files"]
rows, problems, missing_ri = [], [], []
for fname, (model, domain) in FILES.items():
    trajs = json.load(open(os.path.join(a.tau_root, "historical_trajectories", fname)))
    for k, t in enumerate(trajs):
        steps = parse_steps(t["traj"])
        calls = [s for s in steps if s["kind"] == "tool_call"]
        writes = [s for s in calls if s["name"] in WRITE_TOOLS[domain]]
        no_obs = sum(s["recorded"] is None for s in calls)
        bad_args = sum(s["kwargs"] is None for s in calls)
        rr = (t["info"].get("reward_info") or {}).get("reward", "MISSING")
        if t["reward"] not in (0, 0.0, 1, 1.0) or (rr != "MISSING" and rr != t["reward"]):
            problems.append((fname, k, "reward inconsistent", t["reward"], rr))
        if rr == "MISSING":
            missing_ri.append((fname, k, t["reward"]))
        rows.append({
            "traj_key": f"{model}|{domain}|{t['task_id']}|{t['trial']}", "file": fname, "row": k,
            "model": model, "domain": domain, "task_id": t["task_id"], "trial": t["trial"],
            "reward": int(t["reward"]), "n_msgs": len(t["traj"]), "n_calls": len(calls),
            "n_writes": len(writes), "n_write_errors": sum(is_error(s["recorded"]) for s in writes),
            "n_any_errors": sum(is_error(s["recorded"]) for s in calls),
            "transferred": int(any(s["name"] == "transfer_to_human_agents" for s in calls)),
            "n_calls_no_observation": no_obs, "n_calls_bad_args": bad_args,
            "gt_n_writes": sum(x["name"] in WRITE_TOOLS[domain] for x in t["info"]["task"]["actions"]),
            "has_required_outputs": int(bool(t["info"]["task"].get("outputs"))),
        })
df = pd.DataFrame(rows)
assert df.traj_key.is_unique, "duplicate (model, domain, task, trial)"
df.to_csv("results/trajectory_index.csv", index=False)
print(f"trajectories: {len(df)}; tool calls: {df.n_calls.sum()}; write calls: {df.n_writes.sum()}")
print("reward inconsistencies:", len(problems), problems[:3])
print("trajectories without reward_info (label taken from top-level reward):", len(missing_ri), "| their rewards:", sorted({r for *_, r in missing_ri}))
print("calls without recorded observation:", int(df.n_calls_no_observation.sum()),
      "| calls with unparseable arguments:", int(df.n_calls_bad_args.sum()))
print(df.groupby(["model", "domain"]).agg(n=("reward", "size"), tasks=("task_id", "nunique"),
      success=("reward", "mean"), writes=("n_writes", "mean"), any_error=("n_any_errors", lambda s: (s > 0).mean()),
      transferred=("transferred", "mean")).round(3).to_string())
f = df[df.reward == 0]
silent = f[(f.n_any_errors == 0) & (f.transferred == 0)]
print(f"failed: {len(f)}; silent failures (no tool error, no transfer): {len(silent)} ({len(silent)/len(f):.3f})")
print("failed with zero write calls:", int((f.n_writes == 0).sum()))
