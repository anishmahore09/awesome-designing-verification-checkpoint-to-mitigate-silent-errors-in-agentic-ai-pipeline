# Baseline and data validation report (Gate G2)

The "baseline" here is the pipeline as it is, with no checkpoints: what an unguarded agent observes is only the exception path (detector **E**). The deterministic checkpoints C1–C6 are compared against E on the same held-out runs.

## VERIFIED
| Check | Result | Evidence |
|---|---|---|
| Starter environment test | PASS (Python 3.13.18) | logs/01 |
| Trajectory data integrity | 1,980 runs, 14,285 calls; every call has an output; 0 unparseable arguments; 0 reward inconsistencies; 14 runs lack reward_info (all reward 0) | logs/03 |
| Unique run keys | (model, domain, task, trial) unique | validate_data.py assertion |
| Pre-action state reconstruction | 2,026 / 2,026 checked pre-states equal the trajectory's own earlier read of that object | logs/10 |
| Unit tests (Prompt 09/10 acceptance tests) | 12 / 12 pass: clean run → no flag; no authentication → C1; other user's order → C1; no confirmation → C2; ungrounded ID → C4; duplicate write → C5 (single write → none); error + success claim → E and C6; honest error report → no C6; ineligible cancellation → C3 (insured → none); user-stated airline ID → identity | logs/09 |
| Metric code vs. starter evaluator | identical tp/fp/fn/tn, recall 0.22996, precision 0.61582, FPR 0.09524 on test DET predictions | logs/12 |
| Determinism and reproduction | fresh clone + full run gives identical outputs except wall-clock ms | logs/14 |
| Freeze | SHA-256 of rules/config recorded before the test run | logs/05 |

## UNCERTAIN
* The rules are an interpretation of natural-language policies. The cancellation rule accepts any insured reservation (the cancellation reason is not an API argument), which makes it lenient.
* The confirmation lexicon was tuned on dev. Its test behaviour is reported, not guaranteed.
* Outcome labels include output-string checks, so some failures cannot in principle be caught by action checks.
* The state of objects that were never read is taken from write outputs. These states are consistent but were not independently checkable.

## NEEDS CORRECTION (resolved)
| Issue | Resolution |
|---|---|
| Starter `checkpoints.py` flags 1,188 / 1,188 real test runs ("illegal_transition"): its allow-list expects a plan→tool→verify→commit grammar | Not used as a baseline; E is the reference (D020) |
| Execution of tau-bench tool code refused in the AI environment | Data-only state reconstruction, validated as above (D013) |
| Three dev-phase false-positive sources (identity source, basic-economy cabin upgrade, confirmation phrasing) | Fixed before the freeze; diff logged (D017) |
