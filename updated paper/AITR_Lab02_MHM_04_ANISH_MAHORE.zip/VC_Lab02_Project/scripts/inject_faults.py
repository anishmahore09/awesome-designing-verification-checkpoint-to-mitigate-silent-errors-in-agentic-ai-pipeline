"""Controlled fault injection into successful TEST trajectories (detectors already frozen).

For every successful test trajectory with >= 1 successful write call, take the first such
write (position w) and create up to four faulty variants:
  I1_confirmation_removed   the latest user turn before w is replaced by a non-committal turn
  I2_cross_user_target      w's target object (order / reservation / booking user) is replaced
                            by one belonging to a different user (same status), accepted by the API
  I3_same_user_wrong_target w's target is replaced by another object of the SAME user, with the
                            same status, whose ID already appeared in the dialogue (grounded)
  I4_duplicate_write        w is executed twice (copy inserted right after it)
Detection is localised: a variant counts as detected if any checkpoint flags the injected
write step (or, for I4, the inserted duplicate). The same localisation on the untouched
trajectory gives the false-alarm rate at that step.
Usage: python -I scripts/inject_faults.py --tau_root ../data_raw/tau-bench
"""
import argparse, copy, hashlib, json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import numpy as np, pandas as pd
from tau_env import load_db, parse_steps, attach_states, WRITE_TOOLS, is_error
from checkpoints import run_checkpoints, CHECKS

ap = argparse.ArgumentParser()
ap.add_argument("--tau_root", required=True)
a = ap.parse_args()
cfg = json.load(open("configs/experiment.json"))
idx = pd.read_csv("results/trajectory_index.csv")
clean = idx[(idx.split == "test") & (idx.reward == 1)]
dbs = {d: load_db(a.tau_root, d) for d in ("retail", "airline")}
NEUTRAL = "Hmm, let me think about it."


def target_key(domain, name):
    if domain == "retail":
        return None if name == "modify_user_address" else "order_id"
    return "user_id" if name in ("book_reservation", "send_certificate") else "reservation_id"


def candidates(domain, key, cur, state, same_user, seen):
    if key == "order_id":
        o = state["orders"][cur]
        pool = [k for k, v in state["orders"].items() if k != cur and v["status"] == o["status"]
                and ((v["user_id"] == o["user_id"]) == same_user)]
    elif key == "reservation_id":
        r = state["reservations"][cur]
        pool = [k for k, v in state["reservations"].items() if k != cur and ((v["user_id"] == r["user_id"]) == same_user)]
    else:  # user_id (booking / certificate)
        pool = [] if same_user else [k for k in state["users"] if k != cur]
    if same_user:
        pool = [k for k in pool if k in seen]
    return sorted(pool)


def flags_at(steps, domain, pos):
    return {f["check"] for f in run_checkpoints(steps, domain) if f["step"] == pos}


rows = []
for fname, (model, domain) in cfg["trajectory_files"].items():
    trajs = json.load(open(os.path.join(a.tau_root, "historical_trajectories", fname)))
    for _, r in clean[clean.file == fname].iterrows():
        base = attach_states(parse_steps(trajs[int(r.row)]["traj"]), dbs[domain], domain)
        wpos = [i for i, s in enumerate(base) if s["kind"] == "tool_call" and s["name"] in WRITE_TOOLS[domain]
                and not is_error(s["recorded"])]
        if not wpos:
            continue
        w = wpos[0]
        rng = np.random.default_rng(int(hashlib.sha256((r.traj_key + str(cfg["injection"]["seed"])).encode()).hexdigest()[:8], 16))
        seen = "\n".join(s.get("text", "") if s["kind"] == "user" else (s.get("recorded") or "") for s in base[:w] if s["kind"] != "assistant_text")
        variants = {"clean": base}
        # I1
        us = [i for i in range(w) if base[i]["kind"] == "user"]
        if us:
            v = copy.deepcopy(parse_steps(trajs[int(r.row)]["traj"]))
            v[us[-1]]["text"] = NEUTRAL
            variants["I1_confirmation_removed"] = attach_states(v, dbs[domain], domain)
        # I2 / I3
        key = target_key(domain, base[w]["name"])
        if key and base[w]["kwargs"].get(key) is not None:
            state = base[w]["pre_state"]
            cur = base[w]["kwargs"][key]
            ok = (key == "order_id" and cur in state["orders"]) or (key == "reservation_id" and cur in state["reservations"]) or key == "user_id"
            for name, same in (("I2_cross_user_target", False), ("I3_same_user_wrong_target", True)):
                pool = candidates(domain, key, cur, state, same, seen) if ok else []
                if pool:
                    v = copy.deepcopy(parse_steps(trajs[int(r.row)]["traj"]))
                    v[w]["kwargs"][key] = pool[int(rng.integers(len(pool)))]
                    variants[name] = attach_states(v, dbs[domain], domain)
        # I4 (inserted copy at position w+1)
        v = copy.deepcopy(parse_steps(trajs[int(r.row)]["traj"]))
        v.insert(w + 1, copy.deepcopy(v[w]))
        variants["I4_duplicate_write"] = attach_states(v, dbs[domain], domain)
        for vname, steps in variants.items():
            pos = w + 1 if vname == "I4_duplicate_write" else w
            fl = flags_at(steps, domain, pos)
            rows.append({"traj_key": r.traj_key, "task_id": r.task_id, "domain": domain, "model": model,
                         "variant": vname, "write_tool": base[w]["name"], **{c: int(c in fl) for c in CHECKS}})
df = pd.DataFrame(rows)
df.to_csv("results/injection_results.csv", index=False)
print(df.groupby("variant").size())
print(df.groupby("variant")[CHECKS].mean().round(3).to_string())
