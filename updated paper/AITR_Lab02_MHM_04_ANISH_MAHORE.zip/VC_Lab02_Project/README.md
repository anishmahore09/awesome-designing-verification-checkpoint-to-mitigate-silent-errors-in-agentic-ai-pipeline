# Do Deterministic Verification Checkpoints Catch Silent Errors?
### An empirical study on real tool-agent trajectories

Author: **Anish Mahore (MHM_04)**, Department of Information Technology. Course: AI Tools for Research, post-mid-semester implementation paper.
Earlier review: *Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines* (ACM acmsmall format).
Pathway: **B, a controlled comparison** of checkpoint families on held-out real trajectories, plus **controlled fault injection** (the fault catalogue from Prompts 03–07).

## Research questions
1. How common are silent failures in real tool-agent runs, and what share do deterministic checkpoints (review Eq. 5: permission, intent, policy; plus provenance, repetition and report-vs-result checks) flag, at what false-alarm rate?
2. Which failures are caught or missed, and do checkpoints fire before the damaging action?
3. Under controlled fault injection, which checkpoint detects which fault?

## Headline results (held-out test split: 1,188 runs, 99 tasks; 95% task-cluster bootstrap CIs)
| Detector | Recall (failed) | Recall (silent) | False-alarm rate | Precision |
|---|---|---|---|---|
| E exception monitor (no checkpoints) | 0.371 [0.28, 0.46] | 0.000 | 0.329 [0.25, 0.41] | 0.428 |
| C1–C6 deterministic checkpoints | 0.230 [0.16, 0.31] | 0.216 [0.13, 0.31] | 0.095 [0.06, 0.13] | 0.616 |
| E + C1–C6 (layered) | 0.513 [0.43, 0.60] | 0.216 [0.13, 0.31] | 0.375 [0.30, 0.45] | 0.476 |

* 60.2% of all 797 failures are **silent**: no tool error and no human handoff.
* The pre-stated expectation H1 (≥ 50% of silent failures flagged at FPR ≤ 20%) is **not supported**.
* 97.2% of the failures that C1–C6 detect are flagged **before** the offending write executes.
* Airline domain (rules the API does not enforce): 0.42 / 0.35 of silent failures flagged. Retail: 0.03 / 0.12.
* Omissions (19% of failures) are almost never flagged (0.011).
* Injection: encoded faults are caught 100% of the time. A plausible wrong target object of the same user is flagged in only 0.194 of cases, against 0.082 on untouched runs.

## Layout
```
configs/experiment.json      frozen protocol (split, checkpoints, metrics, H1)
src/tau_env.py               data-only loading of tau-bench trajectories + pre-action state reconstruction
src/checkpoints.py           E, C1–C6 (frozen; SHA-256 in results/logs/05_freeze_hashes.log)
scripts/                     fetch_data.sh, run_all.sh, validate_data.py, make_split.py, validate_state.py,
                             run_checkpoints.py, inject_faults.py, evaluate.py, ablation.py, make_figures.py, make_tables.py
tests/test_checkpoints.py    12 unit tests (positive and negative cases)
starter_ai_code/             AI-generated starter code and templates from Prompts 08–13, unchanged
results/                     per-run outputs, flags, tables, numbers.json, logs/
paper/                       main.tex, references.bib, generated/ (auto tables + macros), figures/, main.pdf
docs/research_brief_G1.md    one-page brief
research_decisions.md  baseline_validation.md  ai_assistance_log.md
```

## Reproduce (verified: a fresh copy gives identical results except timing; see results/logs/14_fresh_reproduction.log)
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt        # [TEST REQUIRED] install not run here; versions were already present
bash scripts/fetch_data.sh ../data_raw/tau-bench   # git clone at commit 59a200c6 (data files only are read)
bash scripts/run_all.sh ../data_raw/tau-bench      # ~9 min on 2 CPU cores (the 10,000-resample bootstrap takes ~4 min)
cd paper && pdflatex main && bibtex main && pdflatex main && pdflatex main     # or upload paper/ to Overleaf
```
* CPU only; no GPU, no API keys and no model calls.
* Seeds: 2026 for the split, the bootstrap and the injection choices.
* Only latency numbers change between runs.

## Data and licence
* tau-bench historical trajectories and databases: https://github.com/sierra-research/tau-bench (MIT). The repository is not redistributed here; `fetch_data.sh` clones it.
* None of tau-bench's Python code is imported or run (see `ai_assistance_log.md`).

## Limitations
* Two simulated customer-service domains and two 2024 models.
* Only the deterministic layer is evaluated: no model-based verifier and no recovery.
* The rules are one reader's interpretation of the policy texts.
* See paper Section 6.

## Second-student reproduction checklist
- [ ] `fetch_data.sh` prints `ok tau-bench at 59a200c6...`
- [ ] `results/logs/09_unit_tests.log` ends with `ALL UNIT TESTS PASSED`
- [ ] `results/logs/10_state_reconstruction.log` reports 2026 of 2026 identical
- [ ] `results/table_main.csv`: DET recall_silent = 0.2156, fpr = 0.0952
- [ ] `paper/main.pdf` compiles with no undefined references

Code licence: MIT **[author to confirm]**.
