from collections import Counter

REQUIRED_FIELDS = {"trace_id", "events"}
ALLOWED_TRANSITIONS = {
    ("start", "plan"),
    ("plan", "tool_call"),
    ("tool_call", "tool_result"),
    ("tool_result", "verify"),
    ("verify", "commit"),
    ("plan", "verify"),
    ("verify", "rollback"),
}

def check_trace(trace, max_repeated_tool_calls=3):
    reasons = []
    events = trace.get("events", [])
    if not REQUIRED_FIELDS.issubset(trace):
        return {"predicted_fault": 1, "failure_reasons": ["missing_trace_fields"],
                "checks_per_trace": 1, "first_failure_step": 0}

    previous = None
    tool_calls = 0
    for i, event in enumerate(events):
        event_type = event.get("type")
        if not event_type:
            reasons.append("missing_event_type")
        if previous is not None and (previous, event_type) not in ALLOWED_TRANSITIONS:
            reasons.append("illegal_transition")
        if event_type == "tool_call":
            tool_calls += 1
        else:
            tool_calls = 0
        if tool_calls > max_repeated_tool_calls:
            reasons.append("repeated_tool_cycle")
        if event.get("state_version") is not None and i > 0:
            prior_version = events[i - 1].get("state_version")
            if prior_version is not None and event["state_version"] < prior_version:
                reasons.append("stale_state_version")
        if reasons:
            return {"predicted_fault": 1, "failure_reasons": sorted(set(reasons)),
                    "checks_per_trace": i + 1, "first_failure_step": i}
        previous = event_type

    return {"predicted_fault": 0, "failure_reasons": [],
            "checks_per_trace": len(events), "first_failure_step": None}

def adaptive_check_trace(trace, risk_threshold=1):
    events = trace.get("events", [])
    checks = 0
    risk_events = []
    for i, event in enumerate(events):
        checks += 1
        risk = 0
        if event.get("type") == "tool_call":
            risk += 1
        if event.get("risk_signal") == "high":
            risk += 1
        if risk >= risk_threshold:
            risk_events.append(i)
    if not risk_events:
        return {"predicted_fault": 0, "failure_reasons": [],
                "checks_per_trace": checks, "first_failure_step": None}
    result = check_trace(trace)
    result["checks_per_trace"] = checks + len(risk_events)
    return result
