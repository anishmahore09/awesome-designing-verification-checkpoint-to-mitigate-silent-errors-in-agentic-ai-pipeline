"""Run the frozen checkpoint suite on one split of the natural tau-bench trajectories.
Writes results/flags_<split>.csv (one row per flag) and results/traj_<split>.csv (one row per trajectory).
Labels are joined only after detection, from results/trajectory_index.csv.
Usage: python -I scripts/run_checkpoints.py --tau_root ../data_raw/tau-bench --split dev|test
"""
import argparse, json, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import pandas as pd
from tau_env import load_db, parse_steps, attach_states, WRITE_TOOLS
from checkpoints import run_checkpoints, checks_evaluated, CHECKS

ap = argparse.ArgumentParser()
ap.add_argument("--tau_root", required=True)
ap.add_argument("--split", required=True, choices=["dev", "test"])
a = ap.parse_args()
cfg = json.load(open("configs/experiment.json"))
idx = pd.read_csv("results/trajectory_index.csv")
keep = idx[idx.split == a.split]
dbs = {d: load_db(a.tau_root, d) for d in ("retail", "airline")}
flag_rows, traj_rows = [], []
for fname, (model, domain) in cfg["trajectory_files"].items():
    trajs = json.load(open(os.path.join(a.tau_root, "historical_trajectories", fname)))
    rows = keep[keep.file == fname]
    for _, r in rows.iterrows():
        t = trajs[int(r.row)]
        t0 = time.perf_counter()
        steps = attach_states(parse_steps(t["traj"]), dbs[domain], domain)
        flags = run_checkpoints(steps, domain)        # <- no label, no ground-truth actions passed
        ms = 1000 * (time.perf_counter() - t0)
        write_pos = [i for i, s in enumerate(steps) if s["kind"] == "tool_call" and s["name"] in WRITE_TOOLS[domain]]
        first_write = write_pos[0] if write_pos else None
        rec = {"traj_key": r.traj_key, "ms": ms, "n_steps": len(steps),
               "checks_dense": checks_evaluated(steps, domain, True), "checks_gated": checks_evaluated(steps, domain, False)}
        for c in CHECKS:
            fc = [f for f in flags if f["check"] == c]
            rec[c] = int(bool(fc))
            rec[c + "_first_step"] = fc[0]["step"] if fc else None
        rec["first_flag_step"] = min((f["step"] for f in flags), default=None)
        rec["flag_before_first_write_exec"] = int(any(f["pre_action"] and f["write_index"] == 0 for f in flags)
                                                  or (first_write is not None and any(f["step"] < first_write for f in flags)))
        traj_rows.append(rec)
        for f in flags:
            flag_rows.append({"traj_key": r.traj_key, **f})
pd.DataFrame(flag_rows).to_csv(f"results/flags_{a.split}.csv", index=False)
T = pd.DataFrame(traj_rows).merge(idx, on="traj_key")
T.to_csv(f"results/traj_{a.split}.csv", index=False)
print(f"{a.split}: {len(T)} trajectories, {len(flag_rows)} flags, median {T.ms.median():.2f} ms/trajectory")
